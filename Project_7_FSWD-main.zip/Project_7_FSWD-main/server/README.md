# Full Stack Web Development : Final Project

## Backend

### Database MySQL

#### Run It

(in the terminal of the server) npm start

###### Password for all user for demo : 

admin@sneakrush.com

admin123

eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sZSI6ImFkbWluIiwiaWF0IjoxNzU1NTA1NzcwLCJleHAiOjE3NTU1MDkzNzB9.9KSnMkmiCDuNNhYTlRLz0AEgNdyzAJyGcL9wayoiB8g

jdoe1@example.com

SR!Temp2025

###### Update Git

cd C:\Users\eliao\OneDrive\Bureau\Project_7_FSWD

# 1. Vérifie l’état du repo
git status  

# 2. Ajoute tous les fichiers (modifiés + nouveaux)
git add .

# 3. Crée un commit
git commit -m "update project"

# 4. Pousse sur GitHub (branche main)
git push origin main
