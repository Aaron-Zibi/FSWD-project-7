import { VITE_API_BASE_URL } from "../utils/constants";
export const BASE_URL = VITE_API_BASE_URL;